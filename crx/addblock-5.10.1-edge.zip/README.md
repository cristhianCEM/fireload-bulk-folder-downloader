Bundled Library versions:

PubNub
 https://github.com/pubnub/javascript/releases/tag/v4.27.3

DomPurify
 https://github.com/cure53/DOMPurify/releases/tag/2.2.6

ChartJS
 https://github.com/chartjs/Chart.js/releases/tag/v2.9.4

jQuery
 https://code.jquery.com/jquery-3.5.1.min.js

